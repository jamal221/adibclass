function addCard(IDli){
  if(localStorage.ProductSelected){
    ProductSelected++;
  }
  else{
    ProductSelected=1;
  }
  localStorage.setItem("ProductSelected", ProductSelected);
  document.getElementById("cart-button-number").style.display="block";
  const CardSelect = localStorage.getItem("ProductSelected");
  document.getElementById("cart-button-number").innerHTML=CardSelect;
  const liInfo=document.querySelector("h2.p1");
  // nameCours=liInfo.querySelector("h2").textContent;
  console.log({
   "liInfo":liInfo
  })
}

function clearCart(){
  console.log({
    "ProductSelected":localStorage.getItem("ProductSelected")
  })
  if(localStorage.ProductSelected){
    localStorage.removeItem("ProductSelected");
    document.getElementById("cart-button-number").innerHTML="";
    document.getElementById("cart-button-number").style.display="none";

  }else{
    alert(" فعلا کارتی عریف نشده اشت")
  }
}

function showCartWindowsLoad(){
  if(localStorage.ProductSelected){
    document.getElementById("cart-button-number").innerHTML=localStorage.getItem("ProductSelected");
    document.getElementById("cart-button-number").style.display="block";
  }
}